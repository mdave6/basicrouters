<template>
    <h1> 404 Page not found</h1>
</template>
<template>
<div class="bg-red-800 text-red-200">
    <div class="container mx-auto flex items-center justify-between">
        <h1 class="tracking-tighter text-3xl font-thin">Basic<span class="font-normal">Router</span>
            </h1>
            <nav>
                <ul class="flex space-x-4">
                    <router-link to="/">
                    <li class="py-8 px-4 hover:cursor-pointer hover:bg-blue-300 hover:text-red-600">Home</li>
                    </router-link>
                    <router-link to="/about">
                    <li class="py-8 px-4 hover:cursor-pointer hover:bg-blue-300 hover:text-red-600">About</li> 
                    </router-link>
                    <router-link to="/hello">
                    <li class="py-8 px-4 hover:cursor-pointer hover:bg-blue-300 hover:text-red-600">Hello</li>
                    </router-link>
                    <router-link to="/reference">
                    <li class="py-8 px-4 hover:cursor-pointer hover:bg-blue-300 hover:text-red-600">Reference</li>
                    </router-link>
                </ul>
            </nav>
    </div>
</div>
</template>